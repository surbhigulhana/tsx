"use client"
import React, { useState, useEffect, ReactNode } from "react";
import {
  Table,
  Input,
  Button,
  Modal,
  Checkbox,
  Select,
  Dropdown,
  message,
} from "antd";
import {
  SearchOutlined,
  PlusOutlined,
  MoreOutlined,
  EditOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
import { IoIosNotifications } from "react-icons/io";
import { Layout, Menu, theme } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
import Sidebar from "../../components/Sidebar/page";
import { useRouter } from "next/navigation";
const { Header, Sider, Content } = Layout;
const { Option } = Select;

interface Resolution {
  ResolutionID: number;
  Resolution: string;
  IsLayoutSpecific: boolean;
  UserID: number;
  modifiedDT: string;
  selected?: boolean;
}

interface ChampaingsProps {}

interface ChampaingsState {
  
  data: Resolution[];
  loading: boolean;
  kj: string | null;
  isModalVisible: boolean;
  ResData: Resolution[];
  formData: {
    name: string;
  };
  displayIdToDelete: number | null;
  isModalVisible5: boolean;
  isModalVisible9: boolean;
  editFormData: {
    id: number | null;
    name: string;
  };
}

const Champaings: React.FC<ChampaingsProps> = () => {
  const router = useRouter();
  const [state, setState] = useState<ChampaingsState>({
   
    data: [],
    loading: true,
    kj: sessionStorage.getItem("accessToken"),
    isModalVisible: false,
    ResData: [],
    formData: {
      name: "",
    },
    displayIdToDelete: null,
    isModalVisible5: false,
    isModalVisible9: false,
    editFormData: {
      id: null,
      name: "",
    },
  });
  const {
    token: { colorBgContainer },
  } = theme.useToken();
  const [collapsed, setCollapsed] = useState(false);
  const [data, setData] = useState<Resolution[]>([]);
  const kj = sessionStorage.getItem("accessToken");
  useEffect(() => {
    const fetchData = async () => {
      try {
        const kj = sessionStorage.getItem("accessToken");
        const response = await fetch("https://devapi.signfeed.in/cms/ListResolution", {
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + kj,
          },
        });

        if (response.ok) {
          const result: Resolution[] = await response.json();
          setData(result);
        } else {
          console.error("Error fetching data:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } 
    };

    fetchData();
  }, []);
  

  const handleCheckboxChange = (record: Resolution, checked: boolean) => {
    setState((prevState) => ({
      ...prevState,
      data: prevState.data.map((item) =>
        item === record ? { ...item, selected: checked } : item
      ),
    }));
  };

 
  const columns = [
    {
      title: <Checkbox />,
      dataIndex: "select",

      render: (_: any, record:any) => (
        <Checkbox
          onChange={(e) => handleCheckboxChange(record, e.target.checked)}
          checked={record.selected}
        />
      ),
    },
    {
      title: "ID",
      dataIndex: "resolutionID"
    },
    {
      title: "Resolution",
      dataIndex: "resolution"
    },
    {
        title: "Width",
        dataIndex: "width",
    },
    {
        title: "Height",
        dataIndex: "height",
},
{
title: "Enable",
      dataIndex: "enabled"},
    {
      title: "Action",
      dataIndex: "modifiedDT",

      render: ( record : any) => (
        <>
          <Dropdown
            overlay={
              <Menu style={{ borderTop: "4px solid rgba(38, 34, 98, 1)" }}>
                <Menu.Item
                  key="5"
                  style={{ borderBottom: "1px solid rgba(225, 228, 250, 1)" }}
                  onClick={()=>{showModalEdit(record.ResolutionID)}}
                >
                  <EditOutlined /> Edit
                </Menu.Item>

                <Menu.Item
                  key="8"
                  style={{ borderBottom: "1px solid rgba(225, 228, 250, 1)" }}
                  onClick={() => {
                    showModalDelete(record.ResolutionID);
                  }}
                >
                  <DeleteOutlined /> Delete
                </Menu.Item>

                {/* Add more menu items or customize the dropdown content */}
              </Menu>
            }
            placement="bottomLeft"
          >
            <a
              className="ant-dropdown-link"
              style={{
                color: "black",
                fontSize: "20px",
                padding: "2px",
              }}
              onClick={(e) => e.preventDefault()}
            >
              <MoreOutlined />
            </a>
          </Dropdown>
        </>
      ),
    },
  ];
  const handleSearch = (confirm :any) => {
    confirm();
    // Handle search logic if needed
  };

  const handleReset = (clearFilters : any) => {
    clearFilters();
    // Handle reset logic if needed
  };

  const [isModalVisible, setIsModalVisible] = useState(false);

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleOk = () => {
    // Handle OK action if needed
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };
  // call api to get resolution in drop down
  const [ResData, setResData] = useState([]);
  useEffect(() => {
    const fetchDataR = async () => {
      try {
        const response = await fetch(
          "https://devapi.signfeed.in/cms/ListResolution",
          {
            headers: {
              Accept: "application/json",
              Authorization: "Bearer " + kj,
            },
          }
        );

        console.log("Response:", response); // Log the response

        if (response.ok) {
          const result = await response.json();
          setResData(result);
          console.log("Data:", result); // Log the result
        } else {
          console.error("Error fetching data:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchDataR();
  }, [kj]);
  
  const [formData, setFormData] = useState({
    name: "",
   
  });
// add Resolution
  const handleChange = (field: string, value: string) => {
    setFormData((prevData) => ({ ...prevData, [field]: value }));
  };


  const handleSave = async () => {
    try {
      const response = await fetch(
        "https://devapi.signfeed.in/cms/AddResolution",
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + kj,
          },
          body: JSON.stringify(formData),
        }
      );

      if (response.ok) {
        const responseData = await response.json();
        message.success("Resolution added successfully");
        console.log("Data saved successfully");
        setIsModalVisible(false);
      } else {
        // Handle errors, e.g., show an error message
        console.error("Error saving data");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };
  //  ------------------------------------------------------------------------------------------

  // Delete Layout
  const [displayIdToDelete, setDisplayIdToDelete] = useState(null);
 
  const [isModalVisible5, setIsModalVisible5] = useState(false);
  const showModalDelete = (ResolutionID: React.SetStateAction<null>) => {
    setIsModalVisible5(true);
    setDisplayIdToDelete(ResolutionID);
  };
  const handleOk4 = () => {
    setIsModalVisible5(false);
  };
  const handleCancel4 = () => {
    setIsModalVisible5(false);
  };
  const handleDelete = async () => {
    try {
      console.log(
        "Request Payload:",
        JSON.stringify({ ResolutionID: displayIdToDelete })
      );
      const response = await fetch(
        "https://devapi.signfeed.in/cms/DeleteResolution",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + kj,
          },
          body: JSON.stringify({
            ResolutionID: displayIdToDelete, // Replace with the actual displayId you want to delete
          }),
        }
      );

      if (response.ok) {
        const responseData = await response.json();
        console.log("Response Data:", responseData);
        message.success("Resolution deleted successfully");

        // Add any additional logic you need after successful deletion
      } else {
        // Display error message
        message.error("Error deleting display");
        // Add any additional logic you need for error handling
      }
    } catch (error) {
      // Display error message for fetch error
      message.error("Error deleting display");
      console.error("Error:", error);
    } finally {
      // Close the modal or perform any other necessary cleanup
      handleCancel4();
    }
  };
  // ---------------------------------------------------------------------------------------
  // Edit Layout
  
  const [isModalVisible9, setIsModalVisible9] = useState(false);
  const [editFormData, setEditFormData] = useState({
    id: null,
    name: "",

  });
  const handleChange1 = (field: string, value: string) => {
    setEditFormData((prevData) => ({ ...prevData, [field]: value }));
  };
  const showModalEdit = (ResolutionID: any) => {
//     setIsModalVisible9(true);
  
//     // Find the Resolution with the given ResolutionID from the existing data
//     const ResolutionToEdit = data.Resolution.find((Resolution: { ResolutionID: any; }) => Resolution.ResolutionID === ResolutionID);
//   console.log(ResolutionToEdit)
//     if (ResolutionToEdit) {
//       // Set the edit form data with the details of the selected Resolution
//       setEditFormData({
//         id: ResolutionToEdit.ResolutionID,
//         name: ResolutionToEdit.Resolution,
       
//         // Add other fields as needed
//       });
//     }
  };
  
  console.log(editFormData)
  const handleOk8 = () => {
    setIsModalVisible9(false);
  };
  const handleCancel8 = () => {
    setIsModalVisible9(false);
  };
 
  
  const handleEdit = async () => {
    try {
      const response = await fetch(
        "https://devapi.signfeed.in/cms/UpdateResolution",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + kj,
          },
          body: JSON.stringify(editFormData),
        }
      );
  
      if (response.ok) {
        const responseData = await response.json();
        message.success("Resolution updated successfully");
        console.log("Data saved successfully",responseData);
        setIsModalVisible9(false);
      } else {
        // Handle errors, e.g., show an error message
        console.error("Error updating Resolution:", response.statusText);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };
 
  
  const handleLogout = () => {
    // Remove the access token from session storage
    sessionStorage.removeItem("accessToken");

    router.push("/");
  };

  return (
    // ... (Render JSX remains the same)
    <div>
    <Layout>
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />
      <Layout>
        <Layout className="site-layout">
          <Header
            className="d-flex justify-content-between ps-1 pe-5"
            style={{
              padding: 0,
              background: colorBgContainer,
              position:"fixed",
              // marginTop:"200px",
              marginLeft:"172px"
              ,width:"86%",zIndex:"1"
            }}
          >
            <h4
              style={{
                marginLeft: "90px",
                color: "black",
                marginTop: "20px",
              }}
              className="dashboard"
            >
              {location.pathname.replace("/", "")}
            </h4>
            <div className="d-flex gap-4 align-items-center">
              <div className="position-relative">
                <IoIosNotifications className="fs-4" />
               
              </div>

              <div className="d-flex gap-3 align-items-center dropdown">
                <div onClick={handleLogout}>
                  <img
                    width={32}
                    height={32}
                    src="../../images/user.png"
                    alt=""
                  />
                </div>
              </div>
            </div>
          </Header><br/><br/>
          <Content
            style={{
              margin: "24px 16px",
              padding: 24,
              minHeight: 280,
              background: colorBgContainer,
            }}
          >
            <div className="layone" style={{ marginTop: "-25px" }}>
              <Input
                placeholder="Search Home/tags"
                prefix={<SearchOutlined />}
                style={{
                  width: "40%",
                  background: "rgba(241, 243, 251, 1)",
                  display: "flex",
                  padding: "11px 140px 10px 14px",
                  alignItems: "center",
                  gap: "36px",
                }}
              />
              &nbsp;&nbsp;
              <Button
                type="primary"
                icon={<PlusOutlined />}
                style={{
                  background:
                    "linear-gradient(180deg, #EF4336 0%, #F26139 23%, #F46F3A 43%, #F57C3B 63%, #F8953D 87%, #FAA93F 100%)",
                  width: "170px",
                  height: "47px",
                }}
                onClick={showModal}
              >
                Add Resolution
              </Button>
              <Modal
                title="Add Champaign"
                visible={isModalVisible}
                onOk={handleOk}
                onCancel={handleCancel}
                bodyStyle={{
                  // width: '856px',
                  height: "100px",

                  alignItems: "center",
                  gap: "20px",
                  flexShrink: "0",
                }}
                width={856}
                footer={[
                  <div key="buttons" style={{ textAlign: "center" }}>
                    <Button
                      key="save"
                      type="primary"
                      style={{
                        background:
                          "linear-gradient(180deg, #EF4336 0%, #F26139 23%, #F46F3A 43%, #F57C3B 63%, #F8953D 87%, #FAA93F 100%)",
                        width: "194px",
                        height: "47px",
                        padding: "12px",
                        justifyContent: "center",
                        alignItems: "center",
                        gap: "10px",
                      }}
                      onClick={handleSave}
                    >
                      Save
                    </Button>
                  </div>,
                  <div key="buttons" style={{ textAlign: "center" }}>
                    <Button
                      key="cancel"
                      onClick={handleCancel}
                      style={{
                        width: "194px",
                        height: "47px",
                        padding: "12px",
                        justifyContent: "center",
                        alignItems: "center",
                        gap: "10px",
                        border: "none",
                      }}
                    >
                      Cancel
                    </Button>
                  </div>,
                ]}
              >
                <form>
                  <label htmlFor="name">
                    Name &nbsp;
                    <img src="../images/info.png" alt="info" />
                  </label>
                  <Input
                    id="name"
                    placeholder="Enter Name"
                    style={{ marginTop: "10px" }}
                    value={formData.name}
                    onChange={(e) => handleChange("name", e.target.value)}
                  />

            
                </form>
              </Modal>
            </div>

            <div style={{ overflowX: "auto", marginLeft: "200px" }}>
              
               <Table style={{zIndex:"-1"}} rowClassName={(record, index) => (index % 2 === 0 ? "even-row" : "odd-row")}
                  columns={columns}
                  dataSource={data?.resolution}
                  pagination={{ position: ["bottomRight"], pageSize: 10 }}
                  components={{
                    header: {
                      cell: (props : any) => (
                        <th style={{ background: "#262262", color: "white" }}>
                          {props.children}
                        </th>
                      ),
                    },
                  }}
                />
             
            </div>
          </Content>
        </Layout>
      </Layout>
    </Layout>
    {/* Delete Layout*/}
    <Modal
      title="Delete Layout"
      visible={isModalVisible5}
      onOk={handleOk4}
      onCancel={handleCancel4}
      bodyStyle={{
        height: "80px",
        paddingBottom: "0px",
      }}
      width={856}
      footer={[
        <div key="buttons" style={{ textAlign: "center" }}>
          <Button
            key="save"
            type="primary"
            style={{
              background:
                "linear-gradient(180deg, #EF4336 0%, #F26139 23%, #F46F3A 43%, #F57C3B 63%, #F8953D 87%, #FAA93F 100%)",
              width: "194px",
              height: "47px",
              padding: "12px",
              justifyContent: "center",
              alignItems: "center",
              gap: "10px",
            }}
            onClick={handleDelete}
          >
            Delete
          </Button>
        </div>,
        <div key="buttons" style={{ textAlign: "center" }}>
          <Button
            key="cancel"
            onClick={handleCancel4}
            style={{
              width: "194px",
              height: "47px",
              padding: "12px",
              justifyContent: "center",
              alignItems: "center",
              gap: "10px",
              border: "none",
            }}
          >
            Cancel
          </Button>
        </div>,
      ]}
    >
      <form>
        <center>
          <label htmlFor="resolution" style={{ marginTop: "10px" }}>
            Are You sure you want to delete this Champaign ? &nbsp;
            <br />
            All media will be unassigned and any layout specific media such as
            text/rss will be lost.
            <br /> The layout will be removed from all Schedules.
          </label>
        </center>
      </form>
    </Modal>
    {/* edit Layout*/}
    <Modal
      title="Edit Champaign"
      visible={isModalVisible9}
      onOk={handleOk8}
      onCancel={handleCancel8}
      bodyStyle={{
        height: "180px",
        paddingBottom: "0px",
      }}
      width={856}
      footer={[
        <div key="buttons" style={{ textAlign: "center" }}>
          <Button
            key="save"
            type="primary"
            style={{
              background:
                "linear-gradient(180deg, #EF4336 0%, #F26139 23%, #F46F3A 43%, #F57C3B 63%, #F8953D 87%, #FAA93F 100%)",
              width: "194px",
              height: "47px",
              padding: "12px",
              justifyContent: "center",
              alignItems: "center",
              gap: "10px",
            }}
            onClick={handleEdit}
          >
            Save
          </Button>
        </div>,
        <div key="buttons" style={{ textAlign: "center" }}>
          <Button
            key="cancel"
            onClick={handleCancel8}
            style={{
              width: "194px",
              height: "47px",
              padding: "12px",
              justifyContent: "center",
              alignItems: "center",
              gap: "10px",
              border: "none",
            }}
          >
            Cancel
          </Button>
        </div>,
      ]}
    >
     <form>
  <label htmlFor="id">Id</label>
  <Input
    id="id"
    style={{ marginTop: "10px" }}
    placeholder="Id"
    value={editFormData.id !== null ? editFormData.id : undefined}
    readOnly // Assuming ID should not be editable
  />

  <label htmlFor="name">Name</label>
  <Input
    id="name"
    style={{ marginTop: "10px" }}
    placeholder="Name"
    value={editFormData.name}
    onChange={(e) => handleChange1("name", e.target.value)}
  />


</form>
    </Modal>
  </div>
  );
};

export default Champaings;
