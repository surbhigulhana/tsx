'use client'
import React, { useState, useEffect } from "react";
import { Table, Checkbox, Input, Button } from "antd";
import {
  SearchOutlined,
  CheckCircleOutlined,
  ExclamationCircleOutlined,
  CloseCircleOutlined,
} from "@ant-design/icons";

import { IoIosNotifications } from "react-icons/io";
import Sidebar from "../components/Sidebar/page";
import { Layout, theme } from "antd";


const { Header, Content } = Layout;
interface LayoutData {
 
  layoutID: number;
  layout: string;
  duration: string;
  height: string;
  status: number;
  createdDT: string;
  modifiedDT: string;
  selected?: boolean;
}

const Dashboard: React.FC = () => {
  
  
  // useEffect(() => {
  //   const accessToken = sessionStorage.getItem("accessToken");
  //   if (accessToken) {
  //     // Token exists, redirect to the dashboard
  //     history("/Dashboard");
  //   } else {
  //     history("/");
  //   }
  // }, [history]);

  const [collapsed, setCollapsed] = useState(false);
  const {
    token: { colorBgContainer },
  } = theme.useToken();

  const [data, setData] = useState<LayoutData[]>([]);
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const kj = sessionStorage.getItem("accessToken");
        const response = await fetch("https://devapi.signfeed.in/cms/ListLayout", {
          headers: {
            Accept: "application/json",
            Authorization: "Bearer " + kj,
          },
        });

        if (response.ok) {
          const result: LayoutData[] = await response.json();
          setData(result);
        } else {
          console.error("Error fetching data:", response.statusText);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleCheckboxChange = (record: LayoutData, checked: boolean) => {
    setData((prevData) =>
      prevData.map((item) =>
        item === record ? { ...item, selected: checked } : item
      )
    );
  };
  
  const columns = [
    {
      title: <Checkbox />,
      dataIndex: "select",
      render: (_: any, record: LayoutData) => (
        <Checkbox
          onChange={(e) => handleCheckboxChange(record, e.target.checked)}
          checked={record.selected}
        />
      ),
    },
    {
      title: "Layout",
      dataIndex: "layout",
      filterDropdown: ({
        setSelectedKeys,
        selectedKeys,
        confirm,
        clearFilters,
      }: any) => (
        <div style={{ padding: 8, backgroundColor: "white", color: "white" }}>
          <Input
            placeholder={`Search Layout`}
            value={selectedKeys[0]}
            onChange={(e) =>
              setSelectedKeys(e.target.value ? [e.target.value] : [])
            }
            onPressEnter={() => handleSearch(confirm)}
            style={{ width: 188, marginBottom: 8, display: "block" }}
          />
          <Button
            type="primary"
            onClick={() => handleSearch(confirm)}
            icon={<SearchOutlined style={{ marginRight: 5, color: "white" }} />}
            size="small"
            style={{ width: 90, marginRight: 8 }}
          >
            Search
          </Button>
          <Button
            onClick={() => handleReset(clearFilters)}
            size="small"
            style={{ width: 90 }}
          >
            Reset
          </Button>
        </div>
      ),
      onFilter: (value: any, record: LayoutData) =>
        record.layout.toLowerCase().includes(value.toLowerCase()),
        
    },
    {
      title: "Duration",
      dataIndex: "duration",
      filterDropdown: ({
        setSelectedKeys,
        selectedKeys,
        confirm,
        clearFilters,
      }: any) => (
        <div style={{ padding: 8, backgroundColor: "white", color: "white" }}>
          <Input
            placeholder={`Search Duration`}
            value={selectedKeys[0]}
            onChange={(e) =>
              setSelectedKeys(e.target.value ? [e.target.value] : [])
            }
            onPressEnter={() => handleSearch(confirm)}
            style={{ width: 188, marginBottom: 8, display: "block" }}
          />
          <Button
            type="primary"
            onClick={() => handleSearch(confirm)}
            icon={<SearchOutlined style={{ marginRight: 5, color: "white" }} />}
            size="small"
            style={{ width: 90, marginRight: 8 }}
          >
            Search
          </Button>
          <Button
            onClick={() => handleReset(clearFilters)}
            size="small"
            style={{ width: 90 }}
          >
            Reset
          </Button>
        </div>
      ),
      onFilter: (value: any, record: LayoutData) => {
        const durationString = String(record.duration).toLowerCase();
        const searchValue = String(value).toLowerCase();
        return durationString.includes(searchValue);
      },
    },
    {
      title: "Height",
      dataIndex: "height",
      filterDropdown: ({
        setSelectedKeys,
        selectedKeys,
        confirm,
        clearFilters,
      }: any) => (
        <div style={{ padding: 8, backgroundColor: "white", color: "white" }}>
          <Input
            placeholder={`Search Layout`}
            value={selectedKeys[0]}
            onChange={(e) =>
              setSelectedKeys(e.target.value ? [e.target.value] : [])
            }
            onPressEnter={() => handleSearch(confirm)}
            style={{ width: 188, marginBottom: 8, display: "block" }}
          />
          <Button
            type="primary"
            onClick={() => handleSearch(confirm)}
            icon={<SearchOutlined style={{ marginRight: 5, color: "white" }} />}
            size="small"
            style={{ width: 90, marginRight: 8 }}
          >
            Search
          </Button>
          <Button
            onClick={() => handleReset(clearFilters)}
            size="small"
            style={{ width: 90 }}
          >
            Reset
          </Button>
        </div>
      ),
      onFilter: (value: any, record: LayoutData) =>
        record.height.toLowerCase().includes(value.toLowerCase()),
    },
    {
      title: "Status",
      dataIndex: "status",
      filterDropdown: ({
        setSelectedKeys,
        selectedKeys,
        confirm,
        clearFilters,
      }: any) => (
        <div style={{ padding: 8, backgroundColor: "white", color: "white" }}>
          <Input
            placeholder={`Search Layout`}
            value={selectedKeys[0]}
            onChange={(e) =>
              setSelectedKeys(e.target.value ? [e.target.value] : [])
            }
            onPressEnter={() => handleSearch(confirm)}
            style={{ width: 188, marginBottom: 8, display: "block" }}
          />
          <Button
            type="primary"
            onClick={() => handleSearch(confirm)}
            icon={<SearchOutlined style={{ marginRight: 5, color: "white" }} />}
            size="small"
            style={{ width: 90, marginRight: 8 }}
          >
            Search
          </Button>
          <Button
            onClick={() => handleReset(clearFilters)}
            size="small"
            style={{ width: 90 }}
          >
            Reset
          </Button>
        </div>
      ),
      onFilter: (value: any, record: LayoutData) =>
        record.layout.toLowerCase().includes(value.toLowerCase()),
      render: (status: number) => (
        <>
          {status === 3 && <CloseCircleOutlined style={{ color: "red" }} />}
          {status === 2 && (
            <ExclamationCircleOutlined style={{ color: "blue" }} />
          )}
          {status === 1 && <CheckCircleOutlined style={{ color: "green" }} />}
        </>
      ),
    },
    {
      title: "Created",
      dataIndex: "createdDT",
      filterDropdown: ({
        setSelectedKeys,
        selectedKeys,
        confirm,
        clearFilters,
      }: any) => (
        <div style={{ padding: 8, backgroundColor: "white", color: "white" }}>
          <Input
            placeholder={`Search Layout`}
            value={selectedKeys[0]}
            onChange={(e) =>
              setSelectedKeys(e.target.value ? [e.target.value] : [])
            }
            onPressEnter={() => handleSearch(confirm)}
            style={{ width: 188, marginBottom: 8, display: "block" }}
          />
          <Button
            type="primary"
            onClick={() => handleSearch(confirm)}
            icon={<SearchOutlined style={{ marginRight: 5, color: "white" }} />}
            size="small"
            style={{ width: 90, marginRight: 8 }}
          >
            Search
          </Button>
          <Button
            onClick={() => handleReset(clearFilters)}
            size="small"
            style={{ width: 90 }}
          >
            Reset
          </Button>
        </div>
      ),
      onFilter: (value: any, record: LayoutData) => {
        const layoutString = String(record.createdDT).toLowerCase();
        const searchValue = String(value).toLowerCase();
        return layoutString.includes(searchValue);
      },
    },
    {
      title: "Modify",
      dataIndex: "modifiedDT",
      filterDropdown: ({
        setSelectedKeys,
        selectedKeys,
        confirm,
        clearFilters,
      }: any) => (
        <div style={{ padding: 8, backgroundColor: "white", color: "white" }}>
          <Input
            placeholder={`Search Layout`}
            value={selectedKeys[0]}
            onChange={(e) =>
              setSelectedKeys(e.target.value ? [e.target.value] : [])
            }
            onPressEnter={() => handleSearch(confirm)}
            style={{ width: 188, marginBottom: 8, display: "block" }}
          />
          <Button
            type="primary"
            onClick={() => handleSearch(confirm)}
            icon={<SearchOutlined style={{ marginRight: 5, color: "white" }} />}
            size="small"
            style={{ width: 90, marginRight: 8 }}
          >
            Search
          </Button>
          <Button
            onClick={() => handleReset(clearFilters)}
            size="small"
            style={{ width: 90 }}
          >
            Reset
          </Button>
        </div>
      ),
      onFilter: (value: any, record: LayoutData) =>
        record.modifiedDT.toLowerCase().includes(value.toLowerCase()),
    },
  ];

  const handleSearch = (confirm: any) => {
    confirm();
    // Handle search logic if needed
  };

  const handleReset = (clearFilters: any) => {
    clearFilters();
    // Handle reset logic if needed
  };

  const handleLogout = () => {
    // Remove the access token from session storage
    sessionStorage.removeItem("accessToken");
    // history("/");
  };

return (
    <div>
      <Layout>
        <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />
        <Layout>
          <Layout className="site-layout">
            <Header
              className="d-flex justify-content-between ps-1 pe-5"
              style={{
                padding: 0,
                background: colorBgContainer,
                position: "fixed",
                marginLeft: "200px",
                width: "84%",
                zIndex: "1",
                borderBottom: "1px solid lightgrey",
              }}
            >
              <h4
                style={{
                  marginLeft: "60px",
                  color: "black",
                  marginTop: "20px",
                }}
                className="dashboard"
              >
                {location.pathname.replace("/", "")}
              </h4>
              <div className="d-flex gap-4 align-items-center">
                <div className="position-relative">
                  <IoIosNotifications className="fs-4" />
                </div>
                <div className="d-flex gap-3 align-items-center dropdown">
                  <div onClick={handleLogout}>
                    <img width={32} height={32} src="../images/user.png" alt="" />
                  </div>
                </div>
              </div>
            </Header>
            <Content
              style={{
                margin: "24px 16px",
                padding: 24,
                minHeight: 280,
                background: colorBgContainer,
              }}
            >
                       <div
                className="d-flex justify-content-between align-items-center gap-3"
                style={{ marginLeft: "200px" }}
              >
                <div className="d-flex justify-content-between align-items-end flex-grow-1 bg-white p-3 roudned-3 cardh">
                  <div>
                    <p className="desc">
                      <img src="../images/1.png"></img>
                    </p>
                    <h4 className="mb-0 sub-title">03</h4>
                  </div>
                  <div className="d-flex flex-column align-items-end">
                    <h6 className="red">Total Displays</h6>
                    <p className="mb-0  desc"></p>
                  </div>
                </div>
                <div className="d-flex justify-content-between align-items-end flex-grow-1 bg-white p-3 roudned-3 cardh">
                  <div>
                    <p className="desc">
                      <img src="../images/2.png"></img>
                    </p>
                    <h4 className="mb-0 sub-title">389.87Mib</h4>
                  </div>
                  <div className="d-flex flex-column align-items-end">
                    <h6 className="red">Library size</h6>
                    <p className="mb-0  desc"></p>
                  </div>
                </div>
                <div className="d-flex justify-content-between align-items-end flex-grow-1 bg-white p-3 roudned-3 cardh">
                  <div>
                    <p className="desc">
                      <img src="../images/3.png"></img>
                    </p>
                    <h4 className="mb-0 sub-title">877</h4>
                  </div>
                  <div className="d-flex flex-column align-items-end">
                    <h6 className="red">Total User</h6>
                    <p className="mb-0 desc"></p>
                  </div>
                </div>
                <div className="d-flex justify-content-between align-items-end flex-grow-1 bg-white p-3 roudned-3 cardh">
                  <div>
                    <p className="desc">
                      <img src="../images/4.png"></img>
                    </p>
                    <h4 className="mb-0 sub-title">00</h4>
                  </div>
                  <div className="d-flex flex-column align-items-end">
                    <h6 className="red">Now Showing</h6>
                    <p className="mb-0 desc"></p>
                  </div>
                </div>
              </div>
              <div className="mt-4">
                <div className="container2" style={{ marginLeft: "200px" }}>
                  <div className="col-7">
                    <img
                      src="../images/Bandwidth Usage Graph.png"
                      className="img-fluid"
                      style={{ height: "300px" }}
                    ></img>
                  </div>
                  <div className="col-5">
                    <img
                      src="../images/Library usage chart.png"
                      className="img-fluid"
                      style={{ height: "300px" }}
                    ></img>
                  </div>
                </div>
              </div>
              <div className="mt-4">
                <div style={{ overflowX: "auto", marginLeft: "220px" }}>
                  {loading ? (
                    <p>Loading...</p>
                  ) : (
                    <Table
                    rowClassName={(record, index) => (index % 2 === 0 ? "even-row" : "odd-row")}
                 
                      columns={columns}
                      style={{zIndex:"-1"}}
                      dataSource={data?.layout}
                      pagination={{ position: ["bottomRight"], pageSize: 10 }}
                      components={{
                        header: {
                          cell: (props: { children: string | number | boolean | React.ReactElement<any, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | React.ReactPortal | React.PromiseLikeOfReactNode | null | undefined; }) => (
                            <th
                              style={{ background: "#262262", color: "white" }}
                            >
                              {props.children}
                            </th>
                          ),
                        },
                      }}
                    />
                  )}
                </div>
              </div>
              {/* rest of your content */}
            </Content>
          </Layout>
        </Layout>
      </Layout>
    </div>
  );
};

export default Dashboard;