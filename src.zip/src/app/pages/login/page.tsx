'use client'
import React, { useState } from "react";

import Slider from "../components/Slider/page";
import "./MainLayout.scss";
import "./login.css";
import { Layout } from "antd";
import "react-toastify/dist/ReactToastify.css";
import { useRouter } from "next/navigation";

const { Header } = Layout;

const Login: React.FC = () => {
  const router = useRouter();
  console.log(router)
  const [username, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");

  
  const handleLogin = async () => {
    if (!username || !password) {
      console.error("Please enter both username and password");
      return;
    }

    try {
      const response = await fetch("https://devapi.signfeed.in/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: username,
          password: password,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const accessToken = data.accessToken;
        sessionStorage.removeItem("accessToken");
        sessionStorage.setItem("accessToken", accessToken)    
        router.push('/pages/Dashboard')
       

        setTimeout(() => {
          sessionStorage.removeItem("accessToken");
          router.push('/pages/Login')
        }, 500000);
      } else {
        console.error("Login failed");
      }
    } catch (error) {
      console.error("Error during login:", error);
    }
  };

  return (
    <div>
      <body>
        <div className="container d-flex justify-content-center align-items-center min-vh-100">
          <div className="row border rounded-5 p-3 bg-white shadow box-area">
            <div
              className="col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box"
              style={{
                backgroundImage: "url(../images/login_page_image.png)",
                backgroundPosition: "center",
                backgroundSize: "cover",
              }}
            >
              <div className="slider1">
                <Slider />
              </div>
            </div>
            <div className="col-md-6 right-box">
              <div className="row align-items-center">
                <div className="header-text mb-4">
                  <center>
                    <img src="../images/Logo.png" alt="Logo" />
                    <br />
                    <br />
                    <h4>Welcome Back !</h4>
                  </center>
                </div>
                <label>
                  <b>Username</b>
                </label>
                <div className="input-group mb-3">
                  <input
                    type="text"
                    className="form-control form-control-lg bg-light fs-6"
                    placeholder="Enter User Name"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>
                <label>
                  <b>Password</b>
                </label>
                <div className="input-group mb-1">
                  <input
                    type="password"
                    className="form-control form-control-lg bg-light fs-6"
                    placeholder="Enter Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <div className="input-group mb-5 d-flex justify-content-between">
                  <div className="forgot">
                    <small>
                      <a href="#" style={{ textDecoration: "none" }}>
                        Forgot Password?
                      </a>
                    </small>
                  </div>
                </div>
                <div className="input-group mb-3">
                  <button
                    className="btn btn-lg w-100 fs-6"
                    style={{
                      background:
                        "linear-gradient(158deg, #00ACF5 0%, #003BD4 100%)",
                      boxShadow:
                        "0px 4px 5px rgba(171.53, 173.38, 217.81, 0.38)",
                    }}
                    onClick={handleLogin}
                  >
                    Login
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </body>
    </div>
  );
};

export default Login;


