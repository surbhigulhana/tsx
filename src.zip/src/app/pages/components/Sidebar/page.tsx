import React from "react";
import { AiOutlineDashboard } from "react-icons/ai";
import {
  DesktopOutlined,
  UserOutlined,
  AppstoreAddOutlined,
  DatabaseOutlined,
} from "@ant-design/icons";
import { CgIfDesign } from "react-icons/cg";
import { BsDot } from "react-icons/bs";
import { ImBlog } from "react-icons/im";
import { VscFolderLibrary } from "react-icons/vsc";
import { Layout, Menu, theme } from "antd";
// import { useRouter } from 'next/router';

const { Sider } = Layout;

interface SidebarProps {
  collapsed: boolean;
  setCollapsed: React.Dispatch<React.SetStateAction<boolean>>;
}

const Sidebar: React.FC<SidebarProps> = () => {
  // Use the useRouter hook to get the router object
  // const router = useRouter();

  // const handleMenuClick = ({ key }: { key: React.Key }) => {
  //   if (key === "signout") {
  //     // Handle signout logic if needed
  //   } else {
  //     // Use the router object to push the specified path
  //     router.push(key.toString());
  //   }
  // };

 

  return (
    <>
      <Sider
        trigger={null}
        collapsible
        // collapsed={collapsed}
        className="sidebar"
        style={{ position: "fixed" }}
      >
        <div className="logo">
          <h2 className="text-white fs-5 text-center py-3 mb-0">
            <span className="lg-logo">
              <img src="../images/Logo.png" id="logo1" alt="Logo" />
            </span>
          </h2>
        </div>
        <Menu
          theme="light"
          mode="inline"
          defaultSelectedKeys={[""]}
          // onClick={handleMenuClick}
          items={[
            {
              key:"/pages/Dashboard",
              icon: <AiOutlineDashboard  className="fs-4" color="#EF4336" />,
              label: <span style={{ color: '#EF4336' }}>Dashboard</span>,
             
            },
           
            {
              key:"Design",
              icon: <CgIfDesign  className="fs-4" />,
              label: "Design",
              children: [
                {
                  key: "/Campaigns",
                  icon: <BsDot  className="fs-4" />,
                  label: "Campaigns",
                },
                {
                  key: "/Layouts",
                  icon: <BsDot  className="fs-4" />,
                  label: "Layouts",
                },
                // {
                //   key: "/Templates",
                //   icon: <BsDot  className="fs-4" />,
                //   label: "Templates",
                // },
                {
                  key: "/Resolution",
                  icon: <BsDot  className="fs-4" />,
                  label: "Resolutions",
                },
               
               
              ],
            },
            {
              key: "Library",
              icon: <VscFolderLibrary className="fs-4" />,
              label: "Library",
              children: [
                {
                  key: "/Media",
                  icon: <BsDot  className="fs-4" />,
                  label: "Media",
                },
                // {
                //   key: "/DataSets",
                //   icon: <BsDot  className="fs-4" />,
                //   label: "Datasets",
                // },
              ],
            },
         
            {
              key: "Displays",
              icon: <DesktopOutlined className="fs-4" />,
              label: "Displays",
              children: [
                {
                  key: "/Displays",
                  icon: <BsDot  className="fs-4" />,
                  label: "Display",
                },
                {
                  key: "/DisplayGroup",
                  icon: <BsDot  className="fs-4" />,
                  label: "DisplayGroup",
                },
                // {
                //   key: "/DisplaySettings",
                //   icon: <BsDot  className="fs-4" />,
                //   label: "DisplaySetting",
                // },
                // {
                //   key: "/PlayersVersion",
                //   icon: <BsDot  className="fs-4" />,
                //   label: "PlayersVersion",
                // },
                // {
                //   key: "/Commands",
                //   icon: <BsDot  className="fs-4" />,
                //   label: "Commands",
                // },
              ],
            },
            {
              key: "Admin",
              icon: <UserOutlined  className="fs-4" />,
              label: "Admin",
              children: [
                {
                  key: "/Users",
                  icon: <BsDot  className="fs-4" />,
                  label: "Users",
                },
                {
                  key: "/UserGroup",
                  icon: <BsDot  className="fs-4" />,
                  label: "User Groups",
                }
                ,
                // {
                //   key: "/AdminSetting",
                //   icon: <BsDot  className="fs-4" />,
                //   label: "Setting",
                // },
                // {
                //   key: "/Application",
                //   icon: <BsDot  className="fs-4" />,
                //   label: "Application",
                // },
                {
                  key: "/Module",
                  icon: <BsDot  className="fs-4" />,
                  label: "Module",
                },
                // {
                //   key: "/Transitions",
                //   icon: <BsDot  className="fs-4" />,
                //   label: "Transitions",
                // },
                // {
                //   key: "/Tasks",
                //   icon: <BsDot  className="fs-4" />,
                //   label: "Tasks",
                // },
              ],
            },
          
            {
              key: "Reporting",
              icon: <DatabaseOutlined className="fs-4" />,
              label:"Reporting",
              children: [
                {
                  key: "/DisplayStatistics",
                  icon: <BsDot  className="fs-4" />,
                  label: "Display Statistics",
                },
                {
                  key: "/ProofOfPlay",
                  icon: <BsDot  className="fs-4" />,
                  label: "Proof of Play",
                },{
                  key: "/LibraryUsage",
                  icon: <BsDot  className="fs-4" />,
                  label: "Library Usage",
                },
              ],
            },
            {
              key: "Advanced",
              icon: <AppstoreAddOutlined className="fs-4" />,
              label: "Advanced",
              children: [
                {
                  key: "/Log",
                  icon: <BsDot  className="fs-4" />,
                  label: "Log",
                },
                {
                  key: "/Sessions",
                  icon: <BsDot  className="fs-4" />,
                  label: "Sessions",
                },
              ],
            },
          ]}
        />
      </Sider>
    </>
  );
};

export default Sidebar;
