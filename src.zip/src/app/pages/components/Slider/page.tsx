import React from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap styles
import { Carousel } from 'react-bootstrap';
import "./Slider.css";

const Slider: React.FC = () => {
  return (
    <div>
      <div className="slider-container">
        <Carousel controls={false}>
          <Carousel.Item>
            <h4>Stay Organized and connected</h4>
            <p>Manage your team’s work, projects, and tasks online.</p>
          </Carousel.Item>
          <Carousel.Item>
            <h4>Stay Organized and connected</h4>
            <p>Manage your team’s work, projects, and tasks online.</p>
          </Carousel.Item>
          <Carousel.Item>
            <h4>Stay Organized and connected</h4>
            <p>Manage your team’s work, projects, and tasks online.</p>
          </Carousel.Item>
        </Carousel>
      
    
      </div>
    </div>
  );
};

export default Slider;
